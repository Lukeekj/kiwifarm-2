import { existsSync, mkdirSync, readFileSync, writeFileSync } from "fs";
import path from "path";
import readline from "readline/promises";
import { stdin as input, stdout as output } from "process";
import { randomUUID } from "crypto";
import { spawn } from "child_process";
import { generateProductPackage } from "./lib/product-factory.mjs";

const args = new Set(process.argv.slice(2));
const root = process.cwd();
const sessionDir = path.resolve(process.env.KIWIFY_CHROME_PROFILE || path.join(root, ".sessions", "kiwify-chrome"));
const cdpPort = Number(process.env.KIWIFY_CDP_PORT || 9222);
const appDbPath = path.resolve(process.env.KIWIFARM_DB || path.join(root, "data", "kiwifarm-webview-db.json"));
const outputDir = path.resolve(root, "generated-products");
const kiwifyUrl = process.env.KIWIFY_URL || "https://dashboard.kiwify.com.br";

async function loginOnce() {
  await launchChromeTab(kiwifyUrl);

  console.log("\nChrome aberto na Kiwify.");
  console.log("Faca login manualmente uma vez. A sessao ficara salva em:");
  console.log(sessionDir);
  await waitForEnter("Depois que o painel da Kiwify abrir, pressione Enter aqui. O Chrome pode ficar aberto...");
  console.log("Sessao salva no perfil local. Nas proximas execucoes o KiwiFarm tenta entrar automaticamente.");
}

async function runAutopilot() {
  mkdirSync(outputDir, { recursive: true });
  const niche = readArg("--niche") || "produtividade com inteligencia artificial";
  const ownerId = readArg("--owner-id") || "admin-primary";
  const packageResult = generateProductPackage({ niche, outputDir });
  const localProductId = recordLocalProduct(packageResult, ownerId);
  writeFileSync(path.join(packageResult.files.folder, "kiwify-upload-checklist.txt"), buildChecklist(packageResult));

  console.log("\nProduto gerado:");
  console.log(packageResult.product.name);
  console.log("Arquivos:");
  console.log(packageResult.files);

  const chrome = await launchChromeTab(kiwifyUrl);
  await renderCoverPng(chrome, packageResult.files.coverSvg, packageResult.files.coverPng).catch((error) => {
    console.log(`Nao consegui renderizar capa PNG automaticamente: ${error.message}`);
  });
  const page = await openCdpTab(chrome.port, kiwifyUrl);

  await page.evaluate((payload) => {
    window.localStorage.setItem("kiwifarm_last_product", JSON.stringify(payload));
  }, {
    product: packageResult.product,
    files: packageResult.files
  }).catch(() => undefined);

  const productAreaOpened = await tryOpenProductArea(page);
  const productTypeSelected = await tryChooseProductType(page);
  const fieldsFilled = await tryFillKnownFields(page, packageResult);
  const filesUploaded = await tryUploadKnownFiles(page, packageResult.files);
  const submitted = await trySubmitProductForm(page);
  const finalUrl = await page.currentUrl().catch(() => "");

  updateLocalProduct(localProductId, {
    status: submitted ? "kiwify_submitted" : productAreaOpened ? "kiwify_opened" : "prepared",
    kiwifyAutomation: {
      productAreaOpened,
      productTypeSelected,
      fieldsFilled,
      filesUploaded,
      submitted,
      finalUrl,
      updatedAt: new Date().toISOString()
    }
  });

  console.log("\nA aba da Kiwify esta aberta no Chrome.");
  console.log(`Status Kiwify: area=${productAreaOpened}, tipo=${productTypeSelected}, campos=${fieldsFilled}, arquivos=${filesUploaded}, salvar=${submitted}`);
  console.log("Use estes arquivos para upload se a Kiwify pedir:");
  console.log(`Ebook PDF: ${packageResult.files.ebookPdf}`);
  console.log(`Capa PNG: ${packageResult.files.coverPng}`);
}

async function launchChromeTab(initialUrl) {
  const executablePath = findChrome();
  if (!executablePath) {
    throw new Error("Chrome nao encontrado. Defina CHROME_PATH no ambiente ou instale Google Chrome.");
  }

  mkdirSync(sessionDir, { recursive: true });
  const port = cdpPort;
  if (await isChromeReady(port)) {
    await openUrlInExistingChrome(port, initialUrl);
    return { port };
  }

  const chrome = spawn(executablePath, [
    `--remote-debugging-port=${port}`,
    `--user-data-dir=${sessionDir}`,
    "--profile-directory=Default",
    "--start-maximized",
    "--no-first-run",
    "--disable-first-run-ui",
    initialUrl
  ], {
    detached: true,
    stdio: "ignore",
    windowsHide: false
  });
  chrome.unref();

  await waitForChrome(port);
  return { port };
}

async function openUrlInExistingChrome(port, url) {
  try {
    const targetUrl = `http://127.0.0.1:${port}/json/new?${encodeURIComponent(url)}`;
    let response = await fetch(targetUrl, { method: "PUT" });
    if (!response.ok) response = await fetch(targetUrl);
    if (!response.ok) return false;
    const target = await response.json();
    if (target?.id) {
      await fetch(`http://127.0.0.1:${port}/json/activate/${target.id}`).catch(() => undefined);
    }
    return true;
  } catch {
    return false;
  }
}

async function renderCoverPng(chrome, svgPath, pngPath) {
  const page = await openCdpTab(chrome.port, `file:///${path.resolve(svgPath).replace(/\\/g, "/")}`);
  await page.send("Emulation.setDeviceMetricsOverride", {
    width: 1600,
    height: 2400,
    deviceScaleFactor: 1,
    mobile: false
  });
  await sleep(800);
  const screenshot = await page.send("Page.captureScreenshot", {
    format: "png",
    captureBeyondViewport: true
  });
  writeFileSync(pngPath, Buffer.from(screenshot.data, "base64"));
  await page.close();
}

async function tryOpenProductArea(page) {
  await page.navigate(kiwifyUrl);
  await sleep(1800);
  const currentUrl = await page.currentUrl();
  if (/login|entrar/i.test(currentUrl)) return false;
  const productClicked = await tryClickByTexts(page, ["produtos", "meus produtos", "produto"]);
  await sleep(900);
  const createClicked = await tryClickByTexts(page, [
    "criar produto",
    "novo produto",
    "adicionar produto",
    "cadastrar produto",
    "criar meu primeiro produto",
    "novo"
  ]);
  await sleep(1200);
  const nextUrl = await page.currentUrl();
  return productClicked || createClicked || /product|produto/i.test(nextUrl);
}

async function tryChooseProductType(page) {
  const selected = await tryClickByTexts(page, [
    "produto digital",
    "curso online",
    "e-book",
    "ebook",
    "quero vender um curso",
    "quero apenas aceitar pagamentos",
    "aceitar pagamentos"
  ]);
  if (selected) {
    await sleep(800);
    await tryClickByTexts(page, ["continuar", "proximo", "avancar"]);
  }
  return selected;
}

async function trySubmitProductForm(page) {
  if (!args.has("--publish")) return false;
  await page.evaluate(() => {
    window.scrollTo({ top: document.body.scrollHeight, behavior: "instant" });
  }).catch(() => undefined);
  await sleep(500);
  return tryClickByTexts(page, ["salvar produto", "criar produto", "publicar", "salvar", "continuar"]);
}

async function tryClickByTexts(page, texts) {
  try {
    const clicked = await page.evaluate(({ texts }) => {
      const normalize = (value) => String(value || "")
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .trim();
      const wanted = texts.map(normalize);
      const candidates = Array.from(document.querySelectorAll("button,a,[role='button']"));
      const target = candidates.find((element) => {
        const rect = element.getBoundingClientRect();
        const visible = rect.width > 2 && rect.height > 2 && getComputedStyle(element).visibility !== "hidden";
        const text = normalize(element.innerText || element.textContent || element.getAttribute("aria-label"));
        return visible && text && wanted.some((item) => text.includes(item));
      });
      if (!target) return "";
      target.click();
      return (target.innerText || target.textContent || "").trim();
    }, { texts });
    if (clicked) {
      await sleep(1200);
      console.log(`Clique automatico: ${clicked}`);
      return true;
    }
  } catch {
    // Dynamic dashboards often block generic clicks. Keep the generated files ready.
  }
  return false;
}

async function tryFillKnownFields(page, packageResult) {
  const { product } = packageResult;
  const publicSite = process.env.KIWIFY_PRODUCT_SITE_URL || "https://kiwify.com.br";
  const fieldValues = [
    { labels: ["nome", "titulo", "title", "produto"], value: product.title },
    { labels: ["descricao", "description"], value: product.description },
    { labels: ["preco", "price", "valor"], value: String(product.price).replace(".", ",") },
    { labels: ["garantia", "guarantee"], value: product.guarantee },
    { labels: ["site", "pagina", "página", "url", "link", "instagram"], value: publicSite }
  ];

  let count = 0;
  for (const field of fieldValues) {
    if (await fillByLabelOrPlaceholder(page, field.labels, field.value)) count += 1;
  }
  return count;
}

async function fillByLabelOrPlaceholder(page, labels, value) {
  for (const label of labels) {
    try {
      const filled = await page.evaluate(({ label, value }) => {
        const normalize = (text) => String(text || "")
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "")
          .toLowerCase();
        const wanted = normalize(label);
        const controls = Array.from(document.querySelectorAll("input:not([type='hidden']):not([type='file']), textarea, [contenteditable='true']"));
        const score = (element) => {
          const labelledBy = element.getAttribute("aria-labelledby");
          const labelledText = labelledBy ? String(labelledBy).split(/\s+/).map((id) => document.getElementById(id)?.innerText || "").join(" ") : "";
          const explicitLabel = element.id ? document.querySelector(`label[for="${CSS.escape(element.id)}"]`)?.innerText || "" : "";
          const parentText = element.closest("label,.field,div")?.innerText || "";
          const text = normalize([
            element.getAttribute("placeholder"),
            element.getAttribute("name"),
            element.getAttribute("id"),
            element.getAttribute("aria-label"),
            labelledText,
            explicitLabel,
            parentText
          ].join(" "));
          return text.includes(wanted);
        };
        const element = controls.find(score);
        if (!element) return false;
        element.focus();
        if (element.isContentEditable) {
          element.textContent = value;
        } else {
          const setter = Object.getOwnPropertyDescriptor(element.__proto__, "value")?.set;
          if (setter) setter.call(element, value);
          else element.value = value;
        }
        element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: String(value) }));
        element.dispatchEvent(new Event("change", { bubbles: true }));
        element.blur();
        return true;
      }, { label, value });
      if (filled) return true;
    } catch {
      // Try the next selector. Browser automation should fail soft here.
    }
  }

  return false;
}

async function tryUploadKnownFiles(page, files) {
  const inputs = await page.fileInputs();
  let count = 0;
  for (const input of inputs) {
    try {
      if (input.hint.includes("pdf") || input.hint.includes("ebook") || input.hint.includes("arquivo")) {
        await page.setFileInput(input.nodeId, path.resolve(files.ebookPdf));
        count += 1;
      } else if (input.hint.includes("image") || input.hint.includes("png") || input.hint.includes("cover") || input.hint.includes("capa")) {
        await page.setFileInput(input.nodeId, path.resolve(files.coverPng));
        count += 1;
      }
    } catch {
      // File fields vary across the Kiwify UI. Leave files ready if automatic upload fails.
    }
  }
  return count;
}

function recordLocalProduct(packageResult, ownerId) {
  const now = new Date().toISOString();
  const fallbackDb = { users: [], products: [], plans: [], keys: [], payments: [], messages: [] };
  const db = existsSync(appDbPath) ? JSON.parse(readFileSync(appDbPath, "utf8")) : fallbackDb;
  db.products ||= [];
  const id = randomUUID();

  db.products.push({
    id,
    ownerId,
    name: packageResult.product.name,
    status: "prepared",
    priceCents: Math.round(packageResult.product.price * 100),
    estimatedRevenueCents: Math.round(packageResult.product.estimatedRevenue * 100),
    createdAt: now,
    files: packageResult.files
  });

  mkdirSync(path.dirname(appDbPath), { recursive: true });
  writeFileSync(appDbPath, JSON.stringify(db, null, 2));
  return id;
}

function updateLocalProduct(productId, patch) {
  if (!productId || !existsSync(appDbPath)) return;
  const db = JSON.parse(readFileSync(appDbPath, "utf8"));
  const product = (db.products || []).find((item) => item.id === productId);
  if (!product) return;
  Object.assign(product, patch, { updatedAt: new Date().toISOString() });
  writeFileSync(appDbPath, JSON.stringify(db, null, 2));
}

function findChrome() {
  const envPath = process.env.CHROME_PATH;
  if (envPath && existsSync(envPath)) return envPath;

  const candidates = [
    "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
    path.join(process.env.LOCALAPPDATA || "", "Google\\Chrome\\Application\\chrome.exe")
  ];

  return candidates.find((candidate) => candidate && existsSync(candidate));
}

async function waitForChrome(port) {
  for (let attempt = 0; attempt < 60; attempt++) {
    if (await isChromeReady(port)) return;
    await sleep(250);
  }
  throw new Error("Chrome iniciou, mas a porta de automacao nao respondeu.");
}

async function isChromeReady(port) {
  try {
    const response = await fetch(`http://127.0.0.1:${port}/json/version`);
    return response.ok;
  } catch {
    return false;
  }
}

async function openCdpTab(port, url) {
  let targetResponse = await fetch(`http://127.0.0.1:${port}/json/new?${encodeURIComponent(url)}`, { method: "PUT" });
  if (!targetResponse.ok) {
    targetResponse = await fetch(`http://127.0.0.1:${port}/json/new?${encodeURIComponent(url)}`);
  }
  const target = await targetResponse.json();
  await fetch(`http://127.0.0.1:${port}/json/activate/${target.id}`).catch(() => undefined);
  const client = await CdpClient.connect(target.webSocketDebuggerUrl);
  await client.send("Page.enable");
  await client.send("Runtime.enable");
  await client.send("DOM.enable");
  await sleep(800);

  return {
    send: (method, params) => client.send(method, params),
    evaluate: async (fn, arg) => {
      const expression = `(${fn.toString()})(${JSON.stringify(arg)})`;
      const result = await client.send("Runtime.evaluate", {
        expression,
        awaitPromise: true,
        returnByValue: true
      });
      return result.result?.value;
    },
    navigate: async (nextUrl) => {
      await client.send("Page.navigate", { url: nextUrl });
      await sleep(1200);
    },
    currentUrl: async () => {
      const result = await client.send("Runtime.evaluate", {
        expression: "location.href",
        returnByValue: true
      });
      return result.result?.value || "";
    },
    fileInputs: async () => {
      const documentResult = await client.send("DOM.getDocument", { depth: -1, pierce: true });
      const queryResult = await client.send("DOM.querySelectorAll", {
        nodeId: documentResult.root.nodeId,
        selector: "input[type='file']"
      });
      const inputs = [];
      for (const nodeId of queryResult.nodeIds || []) {
        const attributes = await client.send("DOM.getAttributes", { nodeId });
        const pairs = attributes.attributes || [];
        const attrs = {};
        for (let index = 0; index < pairs.length; index += 2) {
          attrs[pairs[index]] = pairs[index + 1] || "";
        }
        inputs.push({
          nodeId,
          hint: `${attrs.accept || ""} ${attrs.name || ""} ${attrs.id || ""}`.toLowerCase()
        });
      }
      return inputs;
    },
    setFileInput: (nodeId, filePath) => client.send("DOM.setFileInputFiles", { nodeId, files: [filePath] }),
    close: async () => {
      await fetch(`http://127.0.0.1:${port}/json/close/${target.id}`).catch(() => undefined);
      client.close();
    }
  };
}

class CdpClient {
  constructor(socket) {
    this.socket = socket;
    this.nextId = 1;
    this.pending = new Map();
    socket.addEventListener("message", (event) => {
      const message = JSON.parse(event.data);
      if (!message.id || !this.pending.has(message.id)) return;
      const { resolve, reject } = this.pending.get(message.id);
      this.pending.delete(message.id);
      if (message.error) reject(new Error(message.error.message));
      else resolve(message.result || {});
    });
  }

  static async connect(url) {
    const socket = new WebSocket(url);
    await new Promise((resolve, reject) => {
      socket.addEventListener("open", resolve, { once: true });
      socket.addEventListener("error", reject, { once: true });
    });
    return new CdpClient(socket);
  }

  send(method, params = {}) {
    const id = this.nextId++;
    this.socket.send(JSON.stringify({ id, method, params }));
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      setTimeout(() => {
        if (this.pending.has(id)) {
          this.pending.delete(id);
          reject(new Error(`Timeout em CDP ${method}`));
        }
      }, 15000);
    });
  }

  close() {
    this.socket.close();
  }
}

function buildChecklist(packageResult) {
  const { product, files } = packageResult;
  return [
    `Produto: ${product.name}`,
    `Titulo: ${product.title}`,
    `Subtitulo: ${product.subtitle}`,
    `Preco sugerido: R$ ${String(product.price).replace(".", ",")}`,
    `Receita estimada: R$ ${String(product.estimatedRevenue).replace(".", ",")}`,
    `Descricao: ${product.description}`,
    `Garantia: ${product.guarantee}`,
    "",
    `Ebook PDF: ${files.ebookPdf}`,
    `Capa PNG: ${files.coverPng}`,
    `Capa SVG: ${files.coverSvg}`,
    `Roteiros de video: ${files.videoScriptsJson}`,
    `Pagina de vendas: ${files.salesPageHtml}`,
    "",
    "Modo seguro: revisar antes de publicar na Kiwify."
  ].join("\n");
}

function readArg(name) {
  const raw = process.argv.find((arg) => arg.startsWith(`${name}=`));
  return raw ? raw.slice(name.length + 1) : "";
}

async function waitForEnter(message) {
  const rl = readline.createInterface({ input, output });
  await rl.question(`${message}\n`);
  rl.close();
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

if (args.has("--login")) {
  await loginOnce();
} else if (args.has("--run")) {
  await runAutopilot();
} else {
  console.log("Use: npm run autopilot:login ou npm run autopilot:run");
}
