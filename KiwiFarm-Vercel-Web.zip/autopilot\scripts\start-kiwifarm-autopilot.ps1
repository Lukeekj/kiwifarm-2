param(
  [string]$Niche = "produtividade com inteligencia artificial"
)

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$nodeCandidates = @(
  "$env:USERPROFILE\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe",
  "node"
)

$node = $null
foreach ($candidate in $nodeCandidates) {
  if (Test-Path $candidate) {
    $node = $candidate
    break
  }
  $command = Get-Command $candidate -ErrorAction SilentlyContinue
  if ($command) {
    $node = $command.Source
    break
  }
}

if (-not $node) {
  throw "Node.js nao encontrado. Instale Node.js ou rode pelo ambiente do Codex."
}

Write-Host "Iniciando KiwiFarm Autopilot..."
& $node "scripts\kiwifarm-autopilot.mjs" "--run" "--niche=$Niche"
