import importlib.util
import os
import shutil
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
TMP_BASE = Path(os.environ.get("KIWIFARM_RUNTIME_DIR") or "/tmp/kiwifarm-vercel")


def load_api():
    source = ROOT / "kiwifarm_app.py"
    spec = importlib.util.spec_from_file_location("kiwifarm_vercel_app", source)
    if not spec or not spec.loader:
        raise RuntimeError("Nao consegui carregar kiwifarm_app.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules["kiwifarm_vercel_app"] = module
    spec.loader.exec_module(module)

    runtime_data = TMP_BASE / "data"
    runtime_products = TMP_BASE / "generated-products"
    runtime_logs = TMP_BASE / "logs"
    runtime_sessions = TMP_BASE / ".sessions" / "kiwify-chrome"
    runtime_social = TMP_BASE / ".sessions" / "social"
    runtime_data.mkdir(parents=True, exist_ok=True)
    runtime_products.mkdir(parents=True, exist_ok=True)
    runtime_logs.mkdir(parents=True, exist_ok=True)
    runtime_sessions.mkdir(parents=True, exist_ok=True)
    runtime_social.mkdir(parents=True, exist_ok=True)

    seed = ROOT / "data" / "kiwifarm-webview-db.json"
    target = runtime_data / "kiwifarm-webview-db.json"
    if seed.exists() and not target.exists():
        shutil.copyfile(seed, target)

    module.BASE = TMP_BASE
    module.APP_HTML = ROOT / "index.html"
    module.DATA = runtime_data
    module.DB_PATH = target
    module.LEGACY_DB_PATH = runtime_data / "kiwifarm-db.json"
    module.LOG_DIR = runtime_logs
    module.LOG_PATH = runtime_logs / "kiwifarm.log"
    module.PRODUCTS_DIR = runtime_products
    module.SESSION_DIR = runtime_sessions
    module.SOCIAL_SESSION_DIR = runtime_social
    return module.Api()
