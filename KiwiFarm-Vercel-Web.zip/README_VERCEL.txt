KiwiFarm Web - Vercel

Como subir:

1. Envie esta pasta para um repositorio GitHub ou suba o ZIP no Vercel.
2. No Vercel, importe o projeto.
3. Framework preset: Other.
4. Build command: deixe vazio.
5. Output directory: deixe vazio.
6. O Vercel usara vercel.json e as funcoes Python em /api.

URL local de API:

- /api/health
- /api/call

Importante:

Vercel Serverless nao e ideal para banco JSON persistente. Este pacote roda com banco em /tmp durante a execucao. Para producao real, troque para Postgres/Supabase.

O dominio https://kiwifarm.mobile deve ser adicionado em Project Settings > Domains no Vercel e apontado no DNS conforme o Vercel mostrar.
